package ED;

import java.util.Scanner;

class Pilha {
	private int[] pilha;
	private int top;
	private static final int INC = 100;
	Pilha(int max) {
		pilha = new int[max];
		top = 0;
	}
	Pilha() {
		this(INC);
	}
	boolean isEmpty() {
		return top == 0;
	}
	int top() {
		if (isEmpty()) return -1;
		return pilha[top - 1];
	}
	int pop() {
		if (isEmpty()) return -1;
		int res = pilha[top - 1];
		top--;
		return res;
	}
	void push(int item) {
		if (top >= pilha.length) {
			int[] nova = new int[pilha.length+INC];
			for (int i=0; i<top; i++)
				nova[i]=pilha[i];
			pilha = nova;
		}
		pilha[top++]=item;
	}
	@Override
	public String toString() {
		String res = "";
		for (int i = 0; i < top; i++)
			res += pilha[i] + ";";
		return res;
	}
}

class Fila {
	private int[] fila;
	private int primeiro, ultimo, tam;
	private static final int INC = 100;
	Fila(int max) {
		fila = new int[max];
		primeiro = ultimo = tam = 0;
	}
	Fila() {
		this(INC);
	}
	boolean isEmpty() {
		return tam == 0;
	}
	void insere(int item) {
		if (tam == fila.length) {
			int[] novo = new int[fila.length+INC];
			for (int i=0; i<tam; i++)
				novo[i]=fila[(primeiro+i)%fila.length];
			primeiro = 0;
			ultimo = tam;
		}
		fila[ultimo] = item;
		ultimo = (ultimo+1) % fila.length;
		tam++;
	}
	int primeiro() {
		if (isEmpty()) return Integer.MIN_VALUE;
		return fila[primeiro];
	}
	int retira() {
		if (isEmpty()) {
			return Integer.MIN_VALUE;
		}
		int res = fila[primeiro];
		primeiro = (primeiro+1) % fila.length;
		tam--;
		return res;
	}
}

public class TestaPilhaFila {

	public static void main(String[] args) {
		Pilha p = new Pilha(10);
		Fila f = new Fila(10);
		System.out.println("Fornessa 5 inteiros:");
		Scanner sc = new Scanner(System.in);
		for (int i=0; i<5; i++)
			f.insere(sc.nextInt());
		p.push(f.retira());
		p.push(f.retira());
		p.push(f.retira());
		while (! p.isEmpty())
			f.insere(p.pop());
		System.out.print("Conteudo da fila: ");
		while (! f.isEmpty())
			System.out.print(f.retira() + ";");
		sc.close();
	}
}
