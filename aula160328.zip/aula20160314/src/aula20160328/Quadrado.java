/**
 * 
 */
package aula20160328;

/**
 * @author Paulino
 *
 */
public class Quadrado {
	/**
	 * lado � double e imut�vel (qualificador final)
	 */
	private final double lado;
	/**
	 * Construtor de Quadrado
	 * @param l tamanho do lado em double.
	 * 
	 */
	public Quadrado(double l) {
		lado = l;
	}
	/**
	 * Calcula a area do quadrado.
	 * @return area em double.
	 */
	public double area() {
		return lado * lado;
	}
	/**
	 * Sobre carrega o equals do Object.
	 * @param o inst�ncia de quadrado para testar a igualdade.
	 * 
	 */
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Quadrado)) return false;
		return lado == ((Quadrado)o).lado;
	}
	/**
	 * Testa a classe e o m�todo equals.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Quadrado q1 = new Quadrado(3.14);
		Quadrado q2 = new Quadrado(2.71);
		Quadrado q3 = new Quadrado(2.71);
		if (q1.equals(q2))
			System.out.println("q1 equals q2");
		else
			System.out.println("q1 not equals q2");
		if (q2.equals(q3))
			System.out.println("q2 equals q3");
		else
			System.out.println("q2 not equals q3");
		if (q2 == q3)
			System.out.println("q2 == q3");
		else
			System.out.println("q2 != q3");
	}

}
