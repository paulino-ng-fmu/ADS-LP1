package aula20160328;

/**
 * Classe derivada de Quadrado com um m�todo para compara��o de �reas.
 * 
 * @author Paulino
 *
 */
public class QuadradoComparavel extends Quadrado {

	/**
	 * Construtor derivado de Quadrado usando o super-construtor.
	 * 
	 * @param l tamanho do lado.
	 */
	public QuadradoComparavel(double l) {
		super(l);
	}

	/**
	 * Compara quadrados quanto a �rea.
	 * @param o outro quadrado
	 * @return -1 se �rea desta inst�ncia for menor, 0 se igual, 1 se maior.
	 */
	public int compareTo(Object o) {
		Quadrado q = (Quadrado)o;
		if (area()<q.area()) return -1;
		if (area()>q.area()) return 1;
		return 0;
	}
	public static void main(String[] args) {
		QuadradoComparavel q1 = new QuadradoComparavel(3.14);
		QuadradoComparavel q2 = new QuadradoComparavel(2.71);
		QuadradoComparavel q3 = new QuadradoComparavel(2.71);
		if (q1.compareTo(q2)>0)
			System.out.println("q1 maior do que q2");
		if (q1.compareTo(q2)<0)
			System.out.println("q1 menor do que q2");
		if (q2.compareTo(q1)<0)
			System.out.println("q2 menor do que q1");
		if (q2.compareTo(q3)==0)
			System.out.println("q2 egual a q3");
	}

}
