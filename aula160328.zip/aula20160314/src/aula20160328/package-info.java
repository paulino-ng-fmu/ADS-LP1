/**
 * Estas s�o as classes vistas em aula com pequenas modifica��es.
 * Quadrado
 * QuadradoComparavel
 * 
 */
/**
 * @author Paulino
 *
 */
package aula20160328;