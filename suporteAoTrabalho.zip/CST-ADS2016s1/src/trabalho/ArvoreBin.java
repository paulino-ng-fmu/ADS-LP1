package trabalho;
/**
 * O trabalho consiste em criar um jogo para testar a capacidade do
 * usu�rio de fazer contas com n�meros inteiros.
 * O programa deve gerar 3 opera��es aritm�ticas (+,-,*,/)
 * aleat�rias e 4 n�meros, formando express�es do tipo:
 * n1 op1 n2 op2 n3 op3 n4
 * O usu�rio deve responder quanto dar a conta respeitando a
 * prioridade das opera��es e a divis�o inteira. O programa calcula
 * o resultado da express�o e compara para verificar se estar certo.
 * Caso a resposta esteja correta o usu�rio ganha um ponto, caso 
 * contr�rio n�o ganha nada.
 * Esta classe, ArvoreBin, deve fornecer um m�todo est�tico para
 * calcular o valor da express�o.
 * 
 * @author Pang
 *
 */

public class ArvoreBin {
	
	private static class No {
		String conteudo;
		boolean folha;
		No esquerda, direita;
		No(String c, Boolean f) {
			conteudo = c;
			folha = f;
		}
		static int eval(No n) {
			if (n.folha) return Integer.parseInt(n.conteudo);
			switch (n.conteudo.trim().charAt(0)) {
			case '+':
				return eval(n.esquerda) + eval(n.direita);
			case '-':
				return eval(n.esquerda) - eval(n.direita);
			case '*':
				return eval(n.esquerda) * eval(n.direita);
			case '/':
				return eval(n.esquerda) / eval(n.direita);
			}
			return 0;
		}
		boolean isLeaf() {
			return folha;
		}
		private static String visit(No no) {
			if (no.isLeaf()) return no.conteudo;
			return "(" + visit(no.esquerda) + no.conteudo + visit(no.direita) + ")";
		}
	}
	private No raiz;
	public ArvoreBin(String expr) {
		java.util.Scanner sc = new java.util.Scanner(expr);
		int[] opds = new int[4];
		String[] ops = new String[3];
		for (int i=0; i<3; i++) {
			opds[i] = sc.nextInt();
			ops[i] = sc.next().trim();
		}
		opds[3] = sc.nextInt();
		raiz = new No(String.valueOf(opds[0]),true);
		for (int i=0; i<ops.length; i++) {
			append(ops[i],String.valueOf(opds[i+1]));			
		}
		sc.close();
	}
	private void append(String op, String operand) {
		No novo = new No(op, false);
		novo.direita = new No(operand, true);
		if (raiz.isLeaf() || ! morePriority(op,raiz.conteudo)) {
			novo.esquerda = raiz;
			raiz = novo;
		}
		else {
			novo.esquerda = raiz.direita;
			raiz.direita = novo;
		}
	}
	private boolean morePriority(String op1, String op2) {
		switch (op1.charAt(0)) {
		case '*': case '/':
			switch (op2.charAt(0)) {
			case '+': case '-':
				return true;
			}
		}
		return false;
	}
	public int eval() {
		return No.eval(raiz);
	}
	public static int eval(String expr) {
		ArvoreBin ab = new ArvoreBin(expr);
		return ab.eval();
	}
	public static void main(String[] args) {
		System.out.println(eval("2 + 4 / 4 * 2"));
	}
}
