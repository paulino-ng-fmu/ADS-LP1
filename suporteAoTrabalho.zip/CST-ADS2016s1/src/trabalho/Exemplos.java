package trabalho;

public class Exemplos {

	public static void main(String[] args) {
		// exemplos de expressoes que devem ser geradas pelo jogo
		String[] expr = { "3 - 4 * 2 + 1",
				"42 + 3 / 5 * 21", "4 * 2 + 17 * 2"};
		java.util.Scanner sc = new java.util.Scanner(System.in);
		for (String ex : expr) {
			System.out.println("Calcule o valor de: " + ex + " = ");
			int i = sc.nextInt(); sc.nextLine();
			// exemplo de como usar a funcao eval para uma express�o
			int res =  ArvoreBin.eval(ex);
			System.out.println(ex + " = " + res + "\tVoce " + 
			     ((res == i)?"acertou":"errou"));
		}
		sc.close();
	}

}
