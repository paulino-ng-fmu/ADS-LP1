package provaP1;
import java.util.Scanner;

public class Q6 {

	public static void main(String[] args) {
		int a1, a2, a3;
		Scanner sc = new Scanner(System.in);
		int notaFinal;
		System.out.print("a1 (0-3) = ");
		a1 = sc.nextInt();
		System.out.print("a2 (0-2) = ");
		a2 = sc.nextInt();
		System.out.print("a3 (0-5) = ");
		a3 = sc.nextInt();
		notaFinal = a1 + a2 + a3;
		if (notaFinal >= 7)
			System.out.println("Aprovado");
		else if (notaFinal >= 5)
			System.out.println("Reavaliacao");
		else
			System.out.println("Coitado, talvez na proxima");
		sc.close();
	}

}
