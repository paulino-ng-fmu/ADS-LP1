package provaP1;
import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.print("Forneca o numero de faltas: ");
			int nFaltas = sc.nextInt();
			sc.nextLine();
			System.out.print("Forneca a media regular: ");
			float mediaRegular = sc.nextFloat();
			sc.nextLine();
			if ((nFaltas == 0) && (mediaRegular == 0.0F)) {
				sc.close();
				return;
			}
			System.out.println("Expressao logica eh: " +
					(((nFaltas <= 20) && (mediaRegular >= 7.F)) ? "verdadeiro" : "falso"));
		}
	}

}
