package provaP1;
import java.util.Scanner;

public class Q5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		char ch;
		System.out.print("forneca uma letra: ");
		String linha = sc.nextLine();
		if (linha.length()>0)
			ch = linha.charAt(0);
		else
			ch = '\0';
		System.out.println("Primeiro caracter lido = " + ch);
		sc.close();
	}
}
