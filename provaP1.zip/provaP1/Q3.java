package provaP1;

public class Q3 {

	public static void main(String[] args) {
		int i = 42, j = 6, k = 7;
		boolean fatoracao = ((i % j) != (i % k));
		System.out.println("fatoracao = " + fatoracao);
	}

}
